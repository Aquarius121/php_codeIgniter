/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'lv', {
	bold: 'Treknināts',
	italic: 'Kursīvs',
	strike: 'Pārsvītrots',
	subscript: 'Apakšrakstā',
	superscript: 'Augšrakstā',
	underline: 'Pasvītrots'
} );
