/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'id', {
	bold: 'Huruf Tebal',
	italic: 'Huruf Miring',
	strike: 'Strikethrough', // MISSING
	subscript: 'Subscript', // MISSING
	superscript: 'Superscript', // MISSING
	underline: 'Garis Bawah'
} );
