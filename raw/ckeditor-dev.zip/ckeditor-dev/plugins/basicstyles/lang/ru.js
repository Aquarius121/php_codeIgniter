/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ru', {
	bold: 'Полужирный',
	italic: 'Курсив',
	strike: 'Зачеркнутый',
	subscript: 'Подстрочный индекс',
	superscript: 'Надстрочный индекс',
	underline: 'Подчеркнутый'
} );
