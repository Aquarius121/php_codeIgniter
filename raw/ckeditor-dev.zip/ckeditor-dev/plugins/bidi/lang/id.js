﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'id', {
	ltr: 'Arah penulisan dari kiri ke kanan.',
	rtl: 'Arah penulisan dari kanan ke kiri.'
} );
