﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'vi', {
	ltr: 'Văn bản hướng từ trái sang phải',
	rtl: 'Văn bản hướng từ phải sang trái'
} );
