﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ku', {
	copy: 'مافی لەبەرگەرتنەوەی &copy; $1. گشتی پارێزراوه. ورگێڕانی بۆ کوردی لەلایەن هۆژە کۆیی.',
	dlgTitle: 'دەربارەی CKEditor',
	help: 'سەیری $1 بکه بۆ یارمەتی.',
	moreInfo: 'بۆ زانیاری زیاتر دەربارەی مۆڵەتی بەکارهێنان، تکایه سەردانی ماڵپەڕەکەمان بکه:',
	title: 'دەربارەی CKEditor',
	userGuide: 'ڕێپیشاندەری CKEditors'
} );
