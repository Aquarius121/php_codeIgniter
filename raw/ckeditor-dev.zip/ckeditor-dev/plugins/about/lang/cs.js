﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'cs', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'O aplikaci CKEditor',
	help: 'Prohlédněte si $1 pro nápovědu.',
	moreInfo: 'Pro informace o lincenci navštivte naši webovou stránku:',
	title: 'O aplikaci CKEditor',
	userGuide: 'Uživatelská příručka CKEditor'
} );
